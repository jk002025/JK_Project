const { dir } = require('console');
const fs = require('fs')
const path = require('path')
fs.readFile(path.join(__dirname,'index.html'),(error,data)=>{
    if(error){
        console.log(error);
    }else{
        // console.log(data.toString());
        const htmlStr = data.toString()
        // replace正则表达式，匹配/[]/g,g代表全局
        const resulthtmlStr = htmlStr.replace(/[\r\n]/g,'')
        // console.log(resulthtmlStr);
        // 把处理好的字符串写入新的html中
        fs.writeFile(path.join(__dirname,'./newindex.html'),resulthtmlStr,error=>{
            if(error){
                console.log(error);
            }else{
                console.log('写入成功！');
            }
        })
    }
})