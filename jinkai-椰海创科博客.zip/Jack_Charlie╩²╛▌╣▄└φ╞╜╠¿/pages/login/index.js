// 在完成业务的时候，遇到需要复用的，尽可能封装函数
document.querySelector('.login').addEventListener('click',()=>{
    // 快速收集表单插件 form-serialize 
    const form = document.querySelector('.login-form')
    const data = serialize(form , { hash:true , empty:true})
    console.log(data);
    axios({
        url:'http://geek.itheima.net/v1_0/authorizations',
        method:'POST',
        data:data


    }).then(result=>{
        myalert(true,'恭喜您，登录成功')
        // console.log(result);
        console.log(result);
        // 设置定时器
        setTimeout(()=>{
        location.href = '../content/index.html'
        },1500)
       
    }).catch(error=>{
        myalert(false,'用户名或者验证码错误，请检查后重试')
        console.log(error.response.data.message);
    })
})