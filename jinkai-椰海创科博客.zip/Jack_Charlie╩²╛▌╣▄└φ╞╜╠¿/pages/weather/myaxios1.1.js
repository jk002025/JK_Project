function myaxios01(config){
    // 在axios函数调用时，需要集成一个传递查询的功能。params每次调用时不能保证都有。
    // 使用URLSearchParams转换查询字符串
    return new Promise((resolve,reject)=>{
        const xhr = new XMLHttpRequest()
       

        // 1. 做一个判断
        if(config.params){
            // 当config对象中有params

            // 浏览器提供的构造函数
            const paramsObj = new URLSearchParams(config.params)

            // 定义常量，接受字符串
            const queryString =  paramsObj.toString()

            // 将查询参数字符串拼接在问号后面
            config.url+=`?${queryString}`
            
        }
        xhr.open(config.method||'GET',config.url)
        xhr.addEventListener('loadend',()=>{
            if(xhr.status>=200&&xhr.status<300){
                resolve(JSON.parse(xhr.response))
            }else{
                reject(new Error(xhr.response))
            }
        })
        // 判断是否含有请求体
        if(config.data){
            // 处理数据类型

            // 将数据对象转换为JSON字符串
            const jsondata= JSON.stringify(config.data)

            // 请求体内容标记需要自行进行设置，需要携带额外信息，告诉服务器


            // xhr.setRequestHeader('content-type','application/json')

            xhr.setRequestHeader('Content-Type','application/json')

            xhr.send(jsondata)
            // 如果没有请求体数据，正常发送请求
        }else{
        xhr.send()
        }
    })
}