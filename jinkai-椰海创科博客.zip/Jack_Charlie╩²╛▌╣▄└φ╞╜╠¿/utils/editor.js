const { createEditor, createToolbar } = window.wangEditor
  
  const editorConfig = {
      placeholder: '请输入博客内容...',
      onChange(editor) {
        const html = editor.getHtml()
        console.log('editor content', html)


        // 后续收集表单内容

        document.querySelector('.publish-content').value = html

        // 也可以同步到 <textarea>
      }
  }
  
  const editor = createEditor({
    // 选择器和富文本编辑器连接

      selector: '#editor-container',

      html: '<p><br></p>',
    //   配置项：设置编辑器默认内容


      config: editorConfig,
      mode: 'default', // or 'simple'
  })
  
  const toolbarConfig = {}
  
  const toolbar = createToolbar({
      editor,
      selector: '#toolbar-container',
      config: toolbarConfig,
      mode: 'default', // or 'simple'
  })