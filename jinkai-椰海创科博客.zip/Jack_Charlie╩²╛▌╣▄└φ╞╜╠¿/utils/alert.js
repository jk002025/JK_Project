
/**
 * 
 * @param {*} isSuccess 
 * @param {*} msg 
 */
// 警告框函数，封装实用程序函数
function myalert(isSuccess,msg){
    // 获取到盒子对象
    const myalert = document.querySelector('.alert')
 // 三元表达式判断是否执行成功
    myalert.classList.add(isSuccess?'alert-success':'alert-danger')
    myalert.innerHTML = ''
    myalert.innerHTML = msg
    myalert.classList.add('show')

setTimeout (()=> {
    myalert.classList.remove(isSuccess ?'alert-success':'alert-danger')
    myalert.innerHTML = ''
    myalert.classList.remove('show')
},2000)
}